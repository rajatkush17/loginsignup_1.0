const mongoose = require("mongoose");
const express = require("express");
const cors = require("cors");
const User = require("./model");

const app = express();
const PORT = 8080;

app.use(cors());

app.get("/", (req, res) => {
  res.status(200).json({ msg: "welcome" });
});

app.get("/login", async (req, res) => {
  const email = req.query.email;
  const user = await User.findOne({ email });
  if (!user) {
    res.status(200).json({ error: "User not found" });
  } else {
    res.status(200).json(user);
  }
});





app.listen(PORT, () => {
  console.log(`Server at ${PORT}`);
});

mongoose
  .connect("mongodb+srv://rajat:1234@cluster0.1fybo0g.mongodb.net/?retryWrites=true&w=majority")
  .then(() => {
    console.log("connection successful");
  })
  .catch((err) => {
    console.log(err);
  });

app.post("/signup",async(req,res)=>{
  
  const fname=req.query.firstName;
  const lname=req.query.lastName;
  const age=req.query.age;
  const email=req.query.email;
  const password=req.query.password;
  const user = new User({
  
    firstName: fname,
    lastName: lname,
    age:age,
    email:email,
    password: password,
  });
  user
  .save()
  .then(() => {
    console.log("User saved");
  })
  .catch((err) => {
    console.log(err);
  });
})



// const user = new User({
//   firstName: "Rajat",
//   lastName: "Kushwaha",
//   age: 21,
//   email: "rajatkuppcl@gmail.com",
//   password: "aaabbbsss",
// });

// user
//   .save()
//   .then(() => {
//     console.log("User saved");
//   })
//   .catch((err) => {
//     console.log(err);
//   });

// const fetchUser = async () => {
//   const user = await User.findOne({
//     email: "prince@gmail.com",
//   });
//   console.log(user);
// };
// fetchUser();
