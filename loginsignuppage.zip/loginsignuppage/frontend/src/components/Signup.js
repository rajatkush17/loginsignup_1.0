import React from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";


const Signup = () => {
        let  navigate = useNavigate();
    
        const mySignup = async (e) => {
            e.preventDefault();
            const firstName = document.querySelector("#exampleInputFirstName").value;
            const lastName = document.querySelector("#exampleInputLastName").value;
            const age = document.querySelector("#exampleInputAge").value;
            const email = document.querySelector("#exampleInputEmail").value;
            try {
              const response = await axios({
                method: "get",
                url: "http://localhost:8080/login/",
                params: { email },
              });
              console.log(response);
              if (email === response.data.email) {
                alert("Email already exists !");
                navigate("/signup");
              }
            } catch (err) {
              console.log(err);
            }
            const password = document.querySelector("#exampleInputPassword").value;
            const password_again = document.querySelector("#exampleInputPasswordAgain").value;
            console.log(firstName);console.log(lastName);console.log(age);console.log(email);console.log(password);console.log(password_again);
            if(!(password===password_again))
                alert("Passwords do not match");
            
                try{const response = await axios({
                    method: "post",
                    url:"http://localhost:8080/signup/",
                    params:{firstName,lastName,age,email,password},
                 });
                  console.log(response);
                }
                catch(err ) 
                {
                  console.log(err);
                }
                
                


        };








  return (
    <div>
    <form onSubmit={mySignup}>
      <div class="form-group">
        <label for="exampleInputFirstName"><b>First Name</b></label>
        <input
          type="firstName"
          class="form-control"
          id="exampleInputFirstName"
          placeholder="Enter First Name"
        />
        <label for="exampleInputLastName"><b>Last Name</b></label>
        <input
          type="lastName"
          class="form-control"
          id="exampleInputLastName"
          placeholder="Enter Last Name"
        />
        <label for="exampleInputAge"><b>Age</b></label>
        <input
          type="number"
          min="0"
          class="form-control"
          id="exampleInputAge"
          placeholder="Enter Age"
        />
        <label for="exampleInputEmail"><b>Email</b></label>
        <input
          type="email"
          class="form-control"
          id="exampleInputEmail"
          placeholder="Enter Email ID"
        />
        <small id="emailHelp" class="form-text text-muted">
          We'll never share your email with anyone else.
        </small> <br></br>
        <label for="exampleInputPassword"><b>Password</b></label>
        <input
          type="password"
          class="form-control"
          id="exampleInputPassword"
          placeholder="Enter Password"
        />
        <label for="exampleInputPasswordAgain"><b>Password Again</b></label>
        <input
          type="password"
          class="form-control"
          id="exampleInputPasswordAgain"
          placeholder="Enter Password Again"
        />
        
      </div>
      <div>
        <button type="submit" class="btn btn-primary">
         Submit   
        </button> 
      </div>  
    </form>
  </div>
  )
};

export default Signup;