import React from "react";

const Dashboard = () => {
  return <div>This is your profile page.</div>;
};

export default Dashboard;
